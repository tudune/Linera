<!-- cargo-rdme start -->

This module manages the execution of the system application and the user applications in a
Linera chain.

<!-- cargo-rdme end -->

## Contributing

See the [CONTRIBUTING](../CONTRIBUTING.md) file for how to help out.

## License

This project is available under the terms of the [Apache 2.0 license](../LICENSE).

# Meta-Counter Example Application

This application is only used for testing cross-application calls and oracles.

